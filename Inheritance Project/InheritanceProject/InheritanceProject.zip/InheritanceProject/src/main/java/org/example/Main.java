package org.example;

import org.example.people.Client;
import org.example.people.Developer;
import org.example.people.TeamLeader;
import org.example.projects.Project;
import org.example.projects.Task;

public class Main {
    public static void main(String[] args) {
        Project newProject = new Project();
        Client tomaszNowak = new Client("Tomasz", "Nowak", "23.04.2000", "650873957", "tomasznowak12@gmail.com", "Good Company");
        Developer janKowalski = new Developer();
        TeamLeader krzysztofKochanowski = new TeamLeader("Krzysztof", "Kochanowski", "22.06.1990", "766838763", "krzysztofkochanowski@blabla.pl", 100000, "Permanent", "12.12.2012", false, "Front", "Senior", janKowalski);

        krzysztofKochanowski.createATask(newProject, new Task(), "work faster", true, false, 8, krzysztofKochanowski, janKowalski, "Work in progress...");
    }
}
