package org.example.people;

import org.example.projects.Task;
import java.util.List;

public class Developer extends Employee {

    private String backOrFront;
    private String seniority;
    protected List<Task> developersTasks;

    public Developer(String firstName, String lastName, String dateOfBirth, String phoneNumber, String email, int salary, String typeOfContract, String firstDay, boolean onHolidays, String backOrFront, String seniority, List<Task> developersTasks) {
        super();
        this.backOrFront = backOrFront;
        this.seniority = seniority;
        this.developersTasks = developersTasks;
    }

    public Developer() {

    }

    public String getFirstName() {
        return super.firstName;
    }
}
