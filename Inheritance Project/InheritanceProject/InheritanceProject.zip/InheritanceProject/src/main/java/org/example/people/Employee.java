package org.example.people;

import java.time.LocalDate;

abstract class Employee extends Person {

    private int salary;
    private String typeOfContract;
    private String firstDay;
    private boolean onHolidays;

}
