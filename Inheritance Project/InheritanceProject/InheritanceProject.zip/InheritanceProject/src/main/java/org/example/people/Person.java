package org.example.people;

abstract class Person {

    protected String firstName;
    protected String lastName;
    protected String dateOfBirth;
    protected String phoneNumber;
    protected String email;



}
