package org.example.people;

import org.example.projects.Project;
import org.example.projects.Task;

public class TeamLeader extends Developer {

    private Developer ward;

    public TeamLeader(String firstName, String lastName, String dateOfBirth, String phoneNumber, String email, int salary, String typeOfContract, String firstDay, boolean onHolidays, String backOrFront, String seniority, Developer ward) {
        super();
        this.ward = ward;
    }

    public TeamLeader() {

    }

    public String getFirstName() {
        return super.firstName;
    }

    public void createATask(Project name, Task taskName, String description, boolean onFront, boolean onBack, int timeToFinish, TeamLeader leadName, Developer devName, String status) {
        taskName = new Task(description, onFront, onBack, timeToFinish, leadName.getFirstName(), devName.getFirstName(), status);
        name.addNewTask(taskName);
    }

    private void addDevelopersTask(Developer ward, Task name) {
        ward.developersTasks.add(name);
    }

    private void takeDevelopersTask(Developer ward, Task name) {
        ward.developersTasks.remove(name);
    }
}
