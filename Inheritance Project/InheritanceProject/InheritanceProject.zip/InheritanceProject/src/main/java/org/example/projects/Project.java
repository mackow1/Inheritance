package org.example.projects;

import org.example.people.TeamLeader;

import java.time.LocalDate;
import java.util.List;

public class Project {

    String name;
    String description;
    LocalDate startDate;
    LocalDate deadLine;
    String technologies;
    String client;
    List<Task> listOfTasks;

    public Project(String name, String description, LocalDate startDate, LocalDate deadLine, String technologies, String client, List<Task> listOfTasks) {
        this.name = name;
        this.description = description;
        this.startDate = startDate;
        this.deadLine = deadLine;
        this.technologies = technologies;
        this.client = client;
        this.listOfTasks = listOfTasks;
    }

    public Project() {

    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public LocalDate getStartDate() {
        return startDate;
    }
    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }
    public LocalDate getDeadLine() {
        return deadLine;
    }
    public void setDeadLine(LocalDate deadLine) {
        this.deadLine = deadLine;
    }
    public String getTechnologies() {
        return technologies;
    }
    public void setTechnologies(String technologies) {
        this.technologies = technologies;
    }
    public String getClient() {
        return client;
    }
    public void setClient(String client) {
        this.client = client;
    }

    public List<Task> getListOfTasks() {
        return listOfTasks;
    }
    public void addNewTask(Task newTask) {
        listOfTasks.add(newTask);
    }
}
