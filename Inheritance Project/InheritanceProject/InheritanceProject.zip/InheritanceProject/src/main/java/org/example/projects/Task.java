package org.example.projects;

public class Task extends Project {
    private String description;
    private boolean onFront;
    private boolean onBack;
    private int timeToFinish;
    private String leadName;
    private String devName;
    private String status;

    public Task(String description, boolean onFront, boolean onBack, int timeToFinish, String leadName, String devName, String status) {
        this.description = description;
        this.onFront = onFront;
        this.onBack = onBack;
        this.timeToFinish = timeToFinish;
        this.leadName = leadName;
        this.devName = devName;
        this.status = status;
    }

//    public Task() {
//
//    }
}
